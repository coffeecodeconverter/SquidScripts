copy the entire squid Scripts folder somewhere on your machine. 
or keep them in the root of your Squid Install Dir, doesnt matter. 
but keep them in the SAME STRUCTURE they're in!!
(the installConfig.bat file expects certain files in certain places)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Just Run the "InstallConfig.bat" as ADMIN
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
it automates the following:
 - creating shortcut in startup for the Squid System Tray Icon
 - selecting your Squid ACLs and Rules from predefined blocklists (Block windows update, Block Telemetry, both, or none)
 - setting WinHTTP API to use Squid proxy 
 - setting WinINET to use Squid proxy 
 - setting System Environment Variables HTTP_PROXY and HTTPS_PROXY to point to Squid Proxy
 - Copies the "RunAtStartup.bat" into the Squid Directory (where ever it was installed) 
 - Copies the "Proxy_Disable.bat" into the Squid Directory (where ever it was installed) 
 - Copies the "Proxy_Enable.bat" into the Squid Directory (where ever it was installed) 
 - Copies the "Proxy_Show.bat" into the Squid Directory (where ever it was installed) 
 - Creates shortcuts to Start Menu for Proxy Disable / Enable / Show scripts 
 - Creates Scheduled Task on startup, that enforces WinHTTP / WinINET / EnvVar settings, and Squid Proxy


FINALLY
you need to do this MANUALLY
Right-click each shortcut added to start menu (Squid Proxy Disable / Squid Proxy Enable / Squid Proxy Show)
go to "properties", click the advanced button, and mark each of them to "Run as Administrator"


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

You can Re-Run the InstallConfig.bat any time, to overwrite / reconfigure settings. 

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


Usage
On Logon, WinHTTP and WinINET will be configured / overwritten (in case anything has reverted)
then restarts the Squid Service
this is just for good measure. (controlled by the schedeuled task) 

the Shortcut in shell:common Startup loads system tray for easier monitoring 

you can search start menu for "Squid Proxy Disable", "Squid Proxy Enable" or "Squid Proxy Show"
Disbaling fully reverts:
 - WinHTTP Proxy back to default 
 - WinINET Proxy baack to default 
 - Removes the HTTP_PROXY and HTTPS_PROXY EnvVariables 
 - Stops Squid Proxy Service

BUT the Scheduled task is still active 
so, if you just reboot at this stage, the scheduled task ensures its all turned back on again. 

