PLEASE NOTE:
Also blocks .microsoft.com and all subdomains 
so you cant even go to microsoft support pages, download .net frameworks or other legitimate files. 
You can get them from another computer and transfer, thats not too inconveient
othewise, tempoarily disable the proxy, 
or alter the ACL and/or block list 


Blocks all windows update Endpoints, and subdomains 

config file should be placed here:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
**YOUR SQUID INSTALL FOLDER**\etc\squid
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

